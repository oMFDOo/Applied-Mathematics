# hangul-utils


함수 : 
 * Parameter : String
 * Return Type : Bool

사용법 : 
 * "한국어".KoreaContains("한") => True
 * "한국어".KoreaContains("ㅎㄱㅇ") => True
 * "한국어".KoreaContains("하구어") => True
 * "테스트인 한국어 문법".KoreaContains("ㅌㅅㅌㅇ") => True
 
