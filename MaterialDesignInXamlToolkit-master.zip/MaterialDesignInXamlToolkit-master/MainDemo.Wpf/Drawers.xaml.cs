﻿namespace MaterialDesignDemo
{
    public partial class Drawers
    {
        public Drawers() => InitializeComponent();
    }
}
