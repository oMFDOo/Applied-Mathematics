﻿namespace MaterialDesignDemo
{
    public partial class DataGrids
    {
        public DataGrids() => InitializeComponent();
    }
}
