﻿namespace MaterialDesignDemo
{
    public partial class Lists
    {
        public Lists() => InitializeComponent();
    }
}
