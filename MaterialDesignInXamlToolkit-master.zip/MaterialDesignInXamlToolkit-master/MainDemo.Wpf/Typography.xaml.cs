﻿namespace MaterialDesignDemo
{
    public partial class Typography
    {
        public Typography() => InitializeComponent();
    }
}
