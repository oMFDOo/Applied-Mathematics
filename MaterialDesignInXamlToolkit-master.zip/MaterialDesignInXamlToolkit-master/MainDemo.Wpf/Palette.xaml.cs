﻿namespace MaterialDesignDemo
{
    public partial class Palette
    {
        public Palette() => InitializeComponent();
    }
}
