﻿namespace MaterialDesignDemo.Domain
{
    public enum DocumentationLinkType
    {
        Wiki,
        DemoPageSource,
        ControlSource,
        StyleSource,
        Video
    }
}