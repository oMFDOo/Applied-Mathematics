﻿namespace MaterialDesignDemo
{
    public partial class Sliders
    {
        public Sliders() => InitializeComponent();
    }
}
