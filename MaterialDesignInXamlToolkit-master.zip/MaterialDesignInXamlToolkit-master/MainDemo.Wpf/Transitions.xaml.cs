﻿namespace MaterialDesignDemo
{
    public partial class Transitions
    {
        public Transitions() => InitializeComponent();
    }
}
