﻿namespace MaterialDesignDemo
{
    public partial class NavigationRail
    {
        public NavigationRail() => InitializeComponent();
    }
}
