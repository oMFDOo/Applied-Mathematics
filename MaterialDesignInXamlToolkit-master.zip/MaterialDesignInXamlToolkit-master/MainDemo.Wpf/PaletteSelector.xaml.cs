﻿namespace MaterialDesignDemo
{
    public partial class PaletteSelector
    {
        public PaletteSelector() => InitializeComponent();
    }
}
