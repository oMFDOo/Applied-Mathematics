﻿namespace MaterialDesignDemo
{
    public partial class Progress
    {
        public Progress() => InitializeComponent();
    }
}
