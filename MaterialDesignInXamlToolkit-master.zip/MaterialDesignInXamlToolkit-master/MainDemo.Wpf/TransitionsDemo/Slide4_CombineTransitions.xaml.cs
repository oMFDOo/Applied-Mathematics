﻿using System.Windows.Controls;

namespace MaterialDesignDemo.TransitionsDemo
{
    /// <summary>
    /// Interaction logic for Slide4_CombineTransitions.xaml
    /// </summary>
    public partial class Slide4_CombineTransitions : UserControl
    {
        public Slide4_CombineTransitions()
        {
            InitializeComponent();
        }
    }
}
